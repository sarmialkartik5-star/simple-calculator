// ---------- Calculator state ----------
// current  : the number being typed (kept as text so we can add digits easily)
// previous : the first number, saved when an operator is pressed
// operator : the chosen operation (+, -, *, /)
let current = "0";
let previous = null;
let operator = null;
let justCalculated = false; // true right after "=" is pressed
let hasError = false;       // true after something like dividing by zero

const currentDisplay = document.getElementById("current");
const historyDisplay = document.getElementById("history");

// Symbols shown on screen for each operator
const symbols = { "+": "+", "-": "\u2212", "*": "\u00d7", "/": "\u00f7" };

// ---------- Display ----------
function updateDisplay() {
  currentDisplay.textContent = current;
  // Use smaller text when the number is long
  currentDisplay.classList.toggle("long", current.length > 10);

  if (previous !== null && operator !== null) {
    historyDisplay.textContent = previous + " " + symbols[operator];
  } else {
    historyDisplay.textContent = "";
  }
}

// ---------- Math ----------
// Returns the result of "a operator b", or null when dividing by zero
function calculate(a, b, op) {
  const x = parseFloat(a);
  const y = parseFloat(b);

  if (op === "+") return x + y;
  if (op === "-") return x - y;
  if (op === "*") return x * y;
  if (op === "/") return y === 0 ? null : x / y;
  return y;
}

// Removes tiny rounding errors, e.g. 0.1 + 0.2 gives 0.3 instead of 0.30000000000000004
function formatNumber(value) {
  return String(parseFloat(value.toPrecision(12)));
}

function showError() {
  current = "Cannot divide by 0";
  previous = null;
  operator = null;
  hasError = true;
}

// ---------- Button actions ----------
function inputDigit(digit) {
  if (hasError) clearAll();

  if (current === "0" || justCalculated) {
    current = digit; // start a fresh number
    justCalculated = false;
  } else if (current.length < 15) {
    current += digit;
  }
  updateDisplay();
}

function inputDecimal() {
  if (hasError) clearAll();

  if (justCalculated) {
    current = "0.";
    justCalculated = false;
  } else if (!current.includes(".")) {
    current += ".";
  }
  updateDisplay();
}

function chooseOperator(op) {
  if (hasError) return;

  // If an operation is already waiting, finish it first (so 2 + 3 + 4 works)
  if (operator !== null && !justCalculated) {
    const result = calculate(previous, current, operator);
    if (result === null) {
      showError();
      updateDisplay();
      return;
    }
    current = formatNumber(result);
  }

  previous = current;
  operator = op;
  justCalculated = true; // the next digit starts a new number
  updateDisplay();
}

function equals() {
  if (hasError || operator === null) return;

  const result = calculate(previous, current, operator);
  if (result === null) {
    showError();
  } else {
    current = formatNumber(result);
    previous = null;
    operator = null;
    justCalculated = true;
  }
  updateDisplay();
}

function percent() {
  if (hasError) return;
  current = formatNumber(parseFloat(current) / 100);
  updateDisplay();
}

function backspace() {
  if (hasError) return;
  if (justCalculated) return; // do not edit a finished result

  current = current.length > 1 ? current.slice(0, -1) : "0";
  updateDisplay();
}

function clearAll() {
  current = "0";
  previous = null;
  operator = null;
  justCalculated = false;
  hasError = false;
  updateDisplay();
}

// ---------- Mouse / touch input ----------
document.querySelector(".keys").addEventListener("click", function (event) {
  const button = event.target.closest("button");
  if (!button) return;

  const action = button.dataset.action;
  const value = button.dataset.value;

  if (action === "digit") inputDigit(value);
  else if (action === "decimal") inputDecimal();
  else if (action === "operator") chooseOperator(value);
  else if (action === "equals") equals();
  else if (action === "percent") percent();
  else if (action === "backspace") backspace();
  else if (action === "clear") clearAll();
});

// ---------- Keyboard input ----------
document.addEventListener("keydown", function (event) {
  const key = event.key;

  if (key >= "0" && key <= "9") inputDigit(key);
  else if (key === ".") inputDecimal();
  else if (["+", "-", "*", "/"].includes(key)) {
    event.preventDefault(); // stops "/" from opening browser quick-find
    chooseOperator(key);
  } else if (key === "Enter" || key === "=") {
    event.preventDefault();
    equals();
  } else if (key === "%") percent();
  else if (key === "Backspace") backspace();
  else if (key === "Escape" || key === "Delete") clearAll();
});

updateDisplay();
