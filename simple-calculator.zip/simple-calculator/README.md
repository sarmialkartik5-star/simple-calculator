# Simple Calculator

A small calculator built with HTML, CSS and JavaScript. It runs in any web browser and does not need any installation.

## Features

- Addition, subtraction, multiplication and division
- Decimal numbers and percentage
- Delete the last digit (backspace) and clear everything (AC)
- Chained calculations, for example `2 + 3 + 4`
- Message for division by zero instead of a wrong answer
- Rounding fix so `0.1 + 0.2` shows `0.3`
- Works with the mouse, touch screen and keyboard
- Responsive layout that fits phone and desktop screens

## Technologies used

| File | Purpose |
|------|---------|
| `index.html` | Structure of the calculator (display and keys) |
| `style.css` | Colors, layout and button styling |
| `script.js` | Calculator logic and button/keyboard handling |

## How to run

1. Download or clone this repository.
2. Open `index.html` in a web browser (Chrome, Edge, Firefox).

## Keyboard shortcuts

| Key | Action |
|-----|--------|
| `0` to `9` | Enter digits |
| `+` `-` `*` `/` | Operators |
| `.` | Decimal point |
| `Enter` or `=` | Show the result |
| `%` | Percentage |
| `Backspace` | Delete last digit |
| `Esc` or `Delete` | Clear all |

## What I learned

- Building a page layout with HTML and CSS Grid
- Handling button clicks and keyboard events in JavaScript
- Keeping track of state (current number, previous number, operator)
- Handling edge cases such as division by zero and decimal rounding

## Status

Completed as a first practice project. Possible future improvements: calculation history, a dark/light theme switch and scientific functions.
